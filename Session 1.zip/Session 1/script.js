console.log("Script");
var user="Michael";


//declaration and assign
age=28;
let userName="Shakita"

let student;//declaration
student=true;//assign

console.log("student");
//anoying
console.log("Name: "+ userName + "\nAge: " +  age + "\nStudent: " + student);
//cool
let tmp=`Name: ${userName} \n Age: ${age}; \n
Student: ${student}`;
console.log(tmp);

//Exercise 1
let numberChildren=1;
let partnerName="Bambi";
let geoLocation="Italy";
let jobTitle="Developer";
let title="Michael";
let email="mr.mckitrick.mm@gmail.com";
let country="United States";
let planet="Earth";
let sex="male";
let race="white";
let hometown="Half Moon Bay";
let eyes="Brown";
let hair="Brown";
let height="69 inches";
let weight="210 pounds";
let ethnicity="Irish";
let religon="Protestant";
let state="California";
let service="Marine Corps";
let vehicle="Ford Ranger";
let city="San Diego";
let occupation="Software Developer";
let hobby="Sports";


document.write(`<h3>You will be a ${jobTitle} in ${geoLocation}, and married to ${partnerName} with ${numberChildren} kids. Your name is ${title} but you are from ${country}. You are a ${race} ${sex} who is ${ethnicity}. You once were ${service} but now you are a ${occupation} who likes ${hobby}. You have ${eyes}  and${hair} eyes and hair. Your from ${country} ${state} on ${planet}. You are ${weight} and ${height} and you drive a ${vehicle}.</h3>`)





